export enum UserRole {
  USER = 'user',
  ADMIN = 'admin',
  CONTROLLER = 'controller',
  DELIVERY_MAN = 'delivery_man',
}
