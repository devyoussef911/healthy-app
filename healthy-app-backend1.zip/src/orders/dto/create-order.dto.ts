import {
  IsArray,
  IsDecimal,
  IsEnum,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';

class ProductDto {
  @IsNumber()
  id: number; // Change from product_id to id

  @IsNumber()
  quantity: number;

  @IsDecimal()
  price: number;

  @IsOptional()
  @IsString()
  size?: string; // Add size for variations
}

export class CreateOrderDto {
  @IsNotEmpty()
  @IsNumber()
  city_id: number;

  @IsNotEmpty()
  @IsNumber()
  area_id: number;

  @IsNotEmpty()
  @IsNumber()
  user_id: number;

  @IsNotEmpty()
  products: {
    id: number;
    name: string;
    quantity: number;
    price: number;
  }[];

  @IsNotEmpty()
  @IsNumber()
  total_amount: number;

  @IsNotEmpty()
  @IsString()
  payment_method: string;

  @IsNotEmpty()
  @IsString()
  delivery_time: string;
}
