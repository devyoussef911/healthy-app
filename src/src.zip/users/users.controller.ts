// import {
//   Controller,
//   Post,
//   Body,
//   Put,
//   Param,
//   UseGuards,
//   Req,
//   ForbiddenException,
// } from '@nestjs/common';
// import { UsersService } from './users.service';
// import { CreateUserDto } from './dto/create-user.dto';
// import { UpdateUserDto } from './dto/update.user.dto';
// import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

// @Controller(':lang/users')
// export class UsersController {
//   constructor(private readonly usersService: UsersService) {}

//   @Post('register')
//   async register(@Body() createUserDto: CreateUserDto) {
//     try {
//       return await this.usersService.create(createUserDto);
//     } catch (error) {
//       if (error.code === '23505') {
//         throw new ForbiddenException('Email or mobile number already exists');
//       }
//       throw error;
//     }
//   }

//   @Put(':id')
//   @UseGuards(JwtAuthGuard)
//   async updateUser(
//     @Param('id') id: string,
//     @Body() updateUserDto: UpdateUserDto,
//     @Req() req: any,
//   ) {
//     if (req.user.id !== parseInt(id, 10) && req.user.role !== 'admin') {
//       throw new ForbiddenException(
//         'You do not have permission to update this profile',
//       );
//     }
//     return this.usersService.updateUser(parseInt(id, 10), updateUserDto);
//   }
// }

// src/users/users.controller.ts
import {
  Controller,
  Post,
  Get,
  Delete,
  Body,
  Put,
  Param,
  UseGuards,
  Req,
  ForbiddenException,
} from '@nestjs/common';
import { UsersService } from './users.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update.user.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@Controller(':lang/users')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Post('register')
  async register(@Body() createUserDto: CreateUserDto) {
    // Validation: Check if email or phone already exists
    const existingUser = await this.usersService.findByEmailOrPhone(
      createUserDto.email,
      createUserDto.mobileNumber,
    );
    if (existingUser) {
      throw new ForbiddenException(
        'User with this email or phone already exists.',
      );
    }

    // Create the user
    return await this.usersService.create(createUserDto);
  }

  @Put(':id')
  @UseGuards(JwtAuthGuard)
  async updateUser(
    @Param('id') id: string,
    @Body() updateUserDto: UpdateUserDto,
    @Req() req: any,
  ) {
    // Ensure the user is updating their own data
    if (req.user.id !== id) {
      throw new ForbiddenException('You can only update your own profile.');
    }

    // Update user data
    return await this.usersService.update(+id, updateUserDto);
  }

  @Get(':id')
  @UseGuards(JwtAuthGuard)
  async getUserById(@Param('id') id: string, @Req() req: any) {
    // Ensure users can only access their own profile or if they are admin
    if (req.user.id !== id && req.user.role !== 'admin') {
      throw new ForbiddenException('Access denied.');
    }

    // Fetch user data
    return await this.usersService.findById(+id);
  }

  @Delete(':id')
  @UseGuards(JwtAuthGuard)
  async deleteUser(@Param('id') id: string, @Req() req: any) {
    // Ensure users can only delete their own profile or if they are admin
    if (req.user.id !== id && req.user.role !== 'admin') {
      throw new ForbiddenException('You can only delete your own profile.');
    }

    // Delete user data
    return await this.usersService.delete(+id);
  }
}
